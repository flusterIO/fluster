# Fluster Python

For now this package is pretty much useless, but it's being populated by some generated code for the [Fluster](ulld.vercel.app) note taking application to allow users to interact with their data how they see fit.
