import os
from setuptools import setup, find_packages

setup(
    name="flusterIo",
    version=os.environ["DISTRIBUTED_GRPC_VERSION"],
    packages=find_packages(),
    license="MIT",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)
